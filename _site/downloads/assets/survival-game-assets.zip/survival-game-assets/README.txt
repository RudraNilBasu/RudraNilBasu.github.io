-- INSTRUCTIONS --

These assets are from the "How to make a Survival Game" course.

It is shown to use them in the videos.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)